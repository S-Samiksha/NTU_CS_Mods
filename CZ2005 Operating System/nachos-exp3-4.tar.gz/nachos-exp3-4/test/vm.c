#include "syscall.h"
#include "strings.h"

int
main()
{
    Exit(0);

    /* not reached */
}
